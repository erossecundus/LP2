﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string classificacao;

       
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                MessageBox.Show("Valor inválido");
                mskbxPeso.Focus();
            }
        }


        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Valor inválido");
                mskbxAltura.Focus();
            }
        }

        private void mskbxAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true; //desativar beep
            }
        }

        private void mskbxPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true; //desativar beep
            }
        }


        private void btnCalcular_Enter(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            imc = Math.Round(imc, 1);

            if (imc < 18.5)
                classificacao = "Magreza";
            else if (imc < 25)
                classificacao = "Normal";
            else if (imc < 30)
                classificacao = "Sobrepeso";
            else if (imc < 40)
                classificacao = "Obesidade";
            else
                classificacao = "Obesidade grave";

            txtResultado.Text = imc.ToString() + " - " + classificacao;
        }
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            imc = Math.Round(imc,1);

            if (imc < 18.5)
                classificacao = "Magreza";
            else if (imc < 25)
                classificacao = "Normal";
            else if (imc < 30)
                classificacao = "Sobrepeso";
            else if (imc < 40)
                classificacao = "Obesidade";
            else
                classificacao = "Obesidade grave";

            txtResultado.Text = imc.ToString()+" - "+classificacao;
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Text = "";
            mskbxAltura.Text = "";
            txtResultado.Text = "";

            mskbxPeso.Focus();
            peso = 0;
            altura = 0;
            imc = 0;
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
