﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract internal class Empregado
    {

        //criando atributos e propriedades


        private int matricula;              //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("aqui é empregado");
        }
        public Empregado(int mat, string nome, DateTime datax)
        {
            matricula = mat;
            nomeEmpregado = nome;
            dataEntradaEmpresa = datax;
        }


        public int Matricula                //propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }


        //metodos são ações/ comportamentos
        //virtual -> pode ser sobrescrito

        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span =
                DateTime.Today.Subtract(DataEntradaEmpresa);

            return (span.Days);
        }

        //deve ser implementado
        //Derived classes must implement this

        public abstract double SalarioBruto();



    }
}
